export default function Page(){return <div className="page"><h1>reports</h1><p>Module workspace for HRIS360. Add records, approvals, documents and reports here.</p></div>}
