export default function Page(){return <div className="page"><h1>training</h1><p>Module workspace for HRIS360. Add records, approvals, documents and reports here.</p></div>}
