export default function Page(){return <div className="page"><h1>Leave Management</h1><p>Leave balances, requests, approvals and payroll-linked leave deductions.</p></div>}
