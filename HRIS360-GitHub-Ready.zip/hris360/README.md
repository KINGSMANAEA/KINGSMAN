# HRIS360
GitHub-ready starter HRIS for a Philippine company. Built with Next.js, TypeScript and Prisma.

## Modules
- Dashboard
- Employee Master File
- Organization / Branches / Positions
- Recruitment pipeline
- Timekeeping & attendance
- Leave management
- Payroll workspace
- Performance & KPIs
- Employee Relations cases
- Training
- Documents
- Reports & analytics

## Run locally
```bash
npm install
cp .env.example .env
npx prisma db push
npm run dev
```
Open http://localhost:3000.

## Important
Payroll contribution/tax tables are intentionally configurable. Validate current Philippine SSS, PhilHealth, Pag-IBIG and BIR rules before production use.
